
public class RegularTickets {
	String regularTicket;
	
	public RegularTickets(){
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
