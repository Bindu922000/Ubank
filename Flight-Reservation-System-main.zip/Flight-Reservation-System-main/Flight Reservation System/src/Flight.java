
public class Flight {
	 String flight; 
	 
	 
	 public Flight() {
		
	 }
	 
	 public String getFlight() {
		 System.out.println("THIS IS YOUR FLIGHT!!!");
		 return flight;
	 }
	 public void setFlight(String Flight) {
		 this.flight = flight;
	 }
		public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		}
      
}
