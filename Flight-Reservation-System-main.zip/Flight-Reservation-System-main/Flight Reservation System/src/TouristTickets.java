
public class TouristTickets {
	String touristTicket;
	public TouristTickets() {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
